
const  HeaderSection = ({title}) =>
{
    return (
        <div className="section-header ps-0">
                <h1>{title}</h1>
            </div>
    )
}

export default HeaderSection;
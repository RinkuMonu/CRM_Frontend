import ForgotForm from "../../components/forms/ForgotForm";

const Forgot = () =>
{
    return <ForgotForm/>
}

export default Forgot;
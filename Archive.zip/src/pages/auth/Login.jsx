import LoginForm from "../../components/forms/LoginForm";

const Login = () =>
{
  return <LoginForm/>
}

export default Login;